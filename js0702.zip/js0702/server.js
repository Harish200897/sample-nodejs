const express= require("express")
const app = express();
const MongoClient =require('mongodb').MongoClient;
const url ='mongodb://localhost:27017/replie';
const bodyParser = require("body-parser");
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));

app.set('view engine', 'ejs');



MongoClient.connect(url, (err, database) => {
    console.log('MongoBb connected');
    if(err) throw err;
    
    db = database;
    Replies=db.collection('replies');
   
    
});
app.listen(5000, () => {
    console.log("connected");
    });


app.get('/', (req,res,next) => {
    Replies.find({}).toArray((err, replies) => {
        if(err){
            return console.log(err);
        }
        res.render("index", {
            replies:replies

        });
    }); 
});

